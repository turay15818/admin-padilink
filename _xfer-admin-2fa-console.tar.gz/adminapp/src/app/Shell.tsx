/**
 * The console frame: navy rail on the left in both themes, content on the right.
 * The rail carries the brand mark drawn as SVG so it needs no asset pipeline and stays
 * crisp at any zoom.
 */
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useTheme } from '../theme/ThemeProvider';
import { Button } from '../components/ui';
import { Icon, type IconName } from '../components/Icon';
import { setSession } from '../api/client';
import type { AdminIdentity } from '../api/admin';

export function VacancyMark({ size = 30, onNavy = true }: { size?: number; onNavy?: boolean }) {
  const short = onNavy ? '#FFFFFF' : '#2A4E82';
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-label="Vacancy">
      <path d="M17.00 47.00 L39.00 71.00" stroke={short} strokeWidth="15" strokeLinecap="round" fill="none" />
      <path d="M39.00 71.00 L85.00 17.00" stroke="#FF6B2C" strokeWidth="15" strokeLinecap="round" fill="none" />
    </svg>
  );
}

// Drawn icons, not emoji: the rail has to match the front door, and an emoji font
// renders differently on every operating system the console is opened from.
const NAV: { to: string; label: string; icon: IconName; superOnly?: boolean }[] = [
  { to: '/', label: 'Overview', icon: 'overview' },
  { to: '/users', label: 'People', icon: 'people' },
  { to: '/catalog', label: 'Services', icon: 'services' },
  { to: '/audit', label: 'Audit trail', icon: 'audit' },
];

export function Shell({ identity }: { identity: AdminIdentity }) {
  const { t, name, toggle } = useTheme();
  const navigate = useNavigate();

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: t.bg }}>
      {/* rail */}
      <aside style={{
        width: 232, flexShrink: 0, background: t.railBg, color: t.railText,
        display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, height: '100vh',
      }}>
        <div style={{ padding: '20px 18px', display: 'flex', alignItems: 'center', gap: 11 }}>
          <VacancyMark />
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: -0.2 }}>Vacancy</div>
            <div style={{ fontSize: 10.5, letterSpacing: 1.6, color: t.railMuted, fontWeight: 700 }}>ADMIN</div>
          </div>
        </div>

        <nav style={{ padding: '6px 12px', display: 'flex', flexDirection: 'column', gap: 3, flex: 1 }}>
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 11, padding: '10px 12px', borderRadius: 10,
                textDecoration: 'none', fontSize: 13.5, fontWeight: 700,
                color: isActive ? t.railText : t.railMuted,
                background: isActive ? t.railActive : 'transparent',
              })}
            >
              <Icon name={item.icon} size={17} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ padding: 14, borderTop: '1px solid rgba(255,255,255,.10)' }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: t.railText }}>{identity.name}</div>
          <div style={{ fontSize: 11, color: t.railMuted, marginBottom: 10 }}>
            {identity.isSuperAdmin ? 'Super administrator' : 'Administrator'}
          </div>
          <button
            onClick={() => { setSession(null); navigate('/'); }}
            style={{
              width: '100%', padding: '8px 10px', borderRadius: 9, cursor: 'pointer',
              background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.16)',
              color: t.railText, fontSize: 12.5, fontWeight: 700, fontFamily: 'inherit',
            }}
          >
            Sign out
          </button>
        </div>
      </aside>

      {/* content */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <header style={{
          height: 58, borderBottom: `1px solid ${t.border}`, background: t.surface,
          display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 10,
          padding: '0 22px', position: 'sticky', top: 0, zIndex: 30,
        }}>
          <Button
            size="sm"
            tone="subtle"
            onClick={toggle}
            title={name === 'dark' ? 'Switch to light' : 'Switch to dark'}
          >
            {name === 'dark' ? '☀ Light' : '☾ Dark'}
          </Button>
        </header>
        <main style={{ padding: 22, flex: 1 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
