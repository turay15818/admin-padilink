/**
 * Sign-in over the platform's encrypted envelope.
 *
 * The API does not accept a plaintext password — the browser fetches the server's public
 * key, seals the credentials with a one-time AES-256-GCM key, wraps that key with RSA-OAEP,
 * and posts the envelope. This mirrors `padilink-web/src/lib/secureClient.ts` and the mobile
 * client exactly; the console gets no special back door, which is the point.
 */
import { ApiError, config } from './client';

/* ---------- bytes ---------- */
// The buffer type is spelled out: since TS 5.7 a bare Uint8Array may be backed by a
// SharedArrayBuffer, and WebCrypto refuses shared memory.
function bytesToB64(bytes: Uint8Array): string {
  let binary = '';
  for (let index = 0; index < bytes.length; index++) binary += String.fromCharCode(bytes[index]);
  return btoa(binary);
}

function b64ToBytes(value: string): Uint8Array<ArrayBuffer> {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) out[index] = binary.charCodeAt(index);
  return out;
}

function pemToDer(pem: string): Uint8Array<ArrayBuffer> {
  return b64ToBytes(pem.replace(/-----BEGIN [^-]+-----/g, '').replace(/-----END [^-]+-----/g, '').replace(/\s+/g, ''));
}

/* ---------- server public key ---------- */
let publicKeyCache: string | null = null;

async function publicKeyPem(): Promise<string> {
  if (publicKeyCache) return publicKeyCache;
  const response = await fetch(`${config.apiBaseUrl}/api/v1/security/public-key`, {
    headers: { Accept: 'application/json' },
  });
  const text = await response.text();
  const payload = text.trim() ? JSON.parse(text) : null;
  const pem = payload?.data?.publicKeyPem as string | undefined;
  if (!response.ok || !pem) {
    throw new ApiError('Could not load the security key from the API.', response.status);
  }
  publicKeyCache = pem;
  return pem;
}

/* ---------- envelope ---------- */
async function seal(payload: unknown) {
  const keyBytes = crypto.getRandomValues(new Uint8Array(32));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plain = new TextEncoder().encode(JSON.stringify(payload));

  const aesKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['encrypt']);
  const sealed = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, tagLength: 128 }, aesKey, plain));
  // WebCrypto appends the 16-byte tag; the server wants them as separate fields.
  const cipherText = sealed.slice(0, sealed.length - 16);
  const tag = sealed.slice(sealed.length - 16);

  const rsaKey = await crypto.subtle.importKey(
    'spki', pemToDer(await publicKeyPem()), { name: 'RSA-OAEP', hash: 'SHA-256' }, false, ['encrypt']);
  const encryptedKey = new Uint8Array(await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, rsaKey, keyBytes));

  return {
    envelope: {
      encryptedKey: `enc:${bytesToB64(encryptedKey)}`,
      iv: bytesToB64(iv),
      tag: bytesToB64(tag),
      cipherText: bytesToB64(cipherText),
      nonce: bytesToB64(crypto.getRandomValues(new Uint8Array(16))),
      timestampUtc: new Date().toISOString(),
    },
    keyBytes,
  };
}

async function unseal<T>(text: string, keyBytes: Uint8Array<ArrayBuffer>): Promise<{ status?: number; message?: string; data?: T } | null> {
  const parsed = text.trim() ? JSON.parse(text) : null;
  if (!parsed) return null;
  if (!('cipherText' in parsed && 'iv' in parsed && 'tag' in parsed)) return parsed;

  const iv = b64ToBytes(parsed.iv as string);
  const cipherText = b64ToBytes(parsed.cipherText as string);
  const tag = b64ToBytes(parsed.tag as string);
  const combined = new Uint8Array(cipherText.length + tag.length);
  combined.set(cipherText, 0);
  combined.set(tag, cipherText.length);

  const aesKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, tagLength: 128 }, aesKey, combined);
  return JSON.parse(new TextDecoder().decode(plain));
}

export async function securePost<T>(path: string, payload: unknown): Promise<T> {
  const { envelope, keyBytes } = await seal(payload);
  let response: Response;
  try {
    response = await fetch(`${config.apiBaseUrl}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(envelope),
    });
  } catch {
    throw new ApiError(`Cannot reach the API at ${config.apiBaseUrl}. Is it running?`, 0);
  }

  const decoded = await unseal<T>(await response.text(), keyBytes);
  if (!response.ok || decoded?.status === 0) {
    throw new ApiError(decoded?.message?.trim() || `Sign-in failed (${response.status}).`, response.status);
  }
  return decoded?.data as T;
}

/** A stable identifier for this browser, so the API can list the console as a device. */
const DEVICE_KEY = 'vacancy.admin.deviceId';

export function deviceRegistration() {
  let id: string;
  try {
    id = window.localStorage.getItem(DEVICE_KEY) ?? crypto.randomUUID();
    window.localStorage.setItem(DEVICE_KEY, id);
  } catch {
    id = crypto.randomUUID();
  }
  const agent = navigator.userAgent || '';
  const browser = /edg/i.test(agent) ? 'Edge'
    : /chrome/i.test(agent) ? 'Chrome'
    : /firefox/i.test(agent) ? 'Firefox'
    : /safari/i.test(agent) ? 'Safari' : 'Browser';
  return {
    deviceName: `Vacancy Admin · ${browser}`,
    deviceIdentifier: id,
    deviceModel: browser,
    operatingSystem: 'web admin',
    appVersion: '1.0.0',
    firebaseToken: `admin-${id}`,
    appType: 'web',
  };
}
