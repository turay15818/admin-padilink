/** The admin console's wire contract — mirrors ApiVacancy.Application/Admin/DTOs. */
import { apiRequest, setSession, type Session } from './client';
import { deviceRegistration, securePost } from './secure';

const BASE = '/api/v1/secure/admin/console';
const DASHBOARD = '/api/v1/secure/admin/dashboard';
const id = encodeURIComponent;

export type AdminIdentity = {
  userId: string;
  name: string;
  email: string | null;
  roles: string[];
  permissions: string[];
  canManageUsers: boolean;
  canManageCatalog: boolean;
  isSuperAdmin: boolean;
};

export type AuditEntry = {
  id: string;
  actorUserId: string;
  actorName: string;
  actorEmail: string | null;
  action: string;
  actionLabel: string;
  entityType: string;
  entityId: string | null;
  entityLabel: string | null;
  summary: string;
  reason: string | null;
  changesJson: string | null;
  ipAddress: string | null;
  userAgent: string | null;
  severity: number;
  severityLabel: string;
  succeeded: boolean;
  failureReason: string | null;
  at: string;
};

export type AuditPage = {
  items: AuditEntry[];
  totalCount: number;
  pageIndex: number;
  pageSize: number;
  knownActions: string[];
};

export type ConsoleSummary = {
  totalUsers: number; activeUsers: number; suspendedUsers: number; blockedUsers: number;
  newUsers7d: number; newUsers30d: number; providers: number; companies: number;
  categories: number; skills: number;
  adminActions24h: number; sensitiveActions7d: number; failedAdminAttempts7d: number;
  recentActivity: AuditEntry[];
  signupTrend: { day: string; count: number }[];
};

export type AdminUserRow = {
  id: string; name: string; email?: string | null;
  userType: number; userTypeName: string;
  status: number; statusName: string;
  emailVerified: boolean; dateCreated: string;
};

export type AdminUserSearch = { items: AdminUserRow[]; totalCount: number; pageIndex: number; pageSize: number };

export type AdminUserDetail = {
  id: string; name: string; email: string | null; phoneNumber: string | null;
  userType: number; userTypeName: string;
  status: number; statusName: string;
  emailVerified: boolean; phoneVerified: boolean; active: boolean;
  dateCreated: string; lastUpdated: string | null;
  roles: string[];
  bookingsAsCustomer: number; bookingsAsProvider: number; jobsPosted: number;
  classesTaught: number; certificatesEarned: number;
  hasProviderProfile: boolean; providerBusinessName: string | null; providerVerified: boolean;
  recentActivity: AuditEntry[];
};

export type AdminSkill = {
  id: string; categoryId: string; categoryName: string; name: string;
  description: string | null; active: boolean; providerCount: number; dateCreated: string;
};

export type AdminCategory = {
  id: string; name: string; description: string | null; iconUrl: string | null;
  active: boolean; skillCount: number; dateCreated: string; skills: AdminSkill[];
};

/** 2 active · 3 suspended · 4 blocked — matches AccountStatus on the server. */
export const AccountStatus = { Active: 2, Suspended: 3, Blocked: 4 } as const;

export const adminApi = {
  /** Encrypted sign-in, then the identity check. A non-admin is refused here, not at a screen. */
  async signIn(email: string, password: string): Promise<{ session: Session; identity: AdminIdentity }> {
    const auth = await securePost<{
      accessToken: string; refreshToken: string; accessTokenExpiresAt: string;
      user?: { firstName?: string; lastName?: string; email?: string };
    }>('/api/v1/auth/login', { email, password, device: deviceRegistration() });

    const name = `${auth.user?.firstName ?? ''} ${auth.user?.lastName ?? ''}`.trim() || (auth.user?.email ?? email);
    const session: Session = {
      accessToken: auth.accessToken,
      refreshToken: auth.refreshToken,
      expiresAt: auth.accessTokenExpiresAt,
      name,
      email: auth.user?.email ?? email,
    };
    setSession(session);

    try {
      const identity = await adminApi.me();
      return { session, identity };
    } catch (error) {
      setSession(null);   // signed in, but not an administrator — do not leave a token lying around
      throw error;
    }
  },

  me() {
    return apiRequest<AdminIdentity>(`${BASE}/me`);
  },

  summary() {
    return apiRequest<ConsoleSummary>(`${BASE}/summary`);
  },

  // ---- accounts ----
  users(search: string, pageIndex = 1, pageSize = 25) {
    const query = new URLSearchParams({ pageIndex: String(pageIndex), pageSize: String(pageSize) });
    if (search.trim()) query.set('search', search.trim());
    return apiRequest<AdminUserSearch>(`${DASHBOARD}/users?${query}`);
  },

  user(userId: string) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}`);
  },

  setUserStatus(userId: string, status: number, reason: string | null) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}/status`,
      { method: 'POST', body: { status, reason } });
  },

  setUserRoles(userId: string, roles: string[], reason: string | null) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}/roles`,
      { method: 'POST', body: { roles, reason } });
  },

  // ---- service catalogue ----
  catalog(includeArchived: boolean) {
    return apiRequest<AdminCategory[]>(`${BASE}/catalog?includeArchived=${includeArchived}`);
  },

  createCategory(body: { name: string; description?: string | null; iconUrl?: string | null }) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories`, { method: 'POST', body });
  },

  updateCategory(categoryId: string, body: { name: string; description?: string | null; iconUrl?: string | null }) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories/${id(categoryId)}`, { method: 'PUT', body });
  },

  setCategoryActive(categoryId: string, active: boolean, reason?: string | null) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories/${id(categoryId)}/active`,
      { method: 'POST', body: { active, reason } });
  },

  createSkill(body: { categoryId: string; name: string; description?: string | null }) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills`, { method: 'POST', body });
  },

  updateSkill(skillId: string, body: { categoryId: string; name: string; description?: string | null }) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills/${id(skillId)}`, { method: 'PUT', body });
  },

  setSkillActive(skillId: string, active: boolean, reason?: string | null) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills/${id(skillId)}/active`,
      { method: 'POST', body: { active, reason } });
  },

  // ---- audit ----
  audit(filters: {
    search?: string; action?: string; actorUserId?: string; entityId?: string;
    severity?: number; from?: string; to?: string; pageIndex?: number; pageSize?: number;
  }) {
    const query = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim() !== '') query.set(key, String(value));
    });
    return apiRequest<AuditPage>(`${BASE}/audit?${query}`);
  },
};
