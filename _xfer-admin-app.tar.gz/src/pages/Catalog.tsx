/**
 * Services: the categories and skills the whole marketplace is built on.
 *
 * Nothing is ever deleted here — services are retired. A skill with providers attached is
 * still referenced by their profiles and by past bookings, so deletion would tear holes in
 * history; retiring hides it from new work and can be undone.
 */
import { useCallback, useEffect, useState } from 'react';
import { useTheme } from '../theme/ThemeProvider';
import {
  Button, Card, EmptyState, ErrorNote, Field, Input, Loading, Modal, PageHeader, Pill,
  Textarea, Toasts, useToasts,
} from '../components/ui';
import { adminApi, type AdminCategory, type AdminSkill } from '../api/admin';

type CategoryDraft = { id?: string; name: string; description: string; iconUrl: string };
type SkillDraft = { id?: string; categoryId: string; name: string; description: string };

export function Catalog() {
  const { t } = useTheme();
  const { toasts, push } = useToasts();
  const [categories, setCategories] = useState<AdminCategory[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [includeArchived, setIncludeArchived] = useState(false);
  const [busy, setBusy] = useState(false);
  const [categoryDraft, setCategoryDraft] = useState<CategoryDraft | null>(null);
  const [skillDraft, setSkillDraft] = useState<SkillDraft | null>(null);

  const load = useCallback(() => {
    adminApi.catalog(includeArchived)
      .then(result => { setCategories(result); setError(null); })
      .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : 'Could not load the catalogue.'));
  }, [includeArchived]);
  useEffect(load, [load]);

  const run = (work: Promise<unknown>, done: string) => {
    setBusy(true);
    work
      .then(() => { push(done); load(); setCategoryDraft(null); setSkillDraft(null); })
      .catch((caught: unknown) => push(caught instanceof Error ? caught.message : 'That did not work.', 'error'))
      .finally(() => setBusy(false));
  };

  const saveCategory = () => {
    if (!categoryDraft) return;
    const body = {
      name: categoryDraft.name.trim(),
      description: categoryDraft.description.trim() || null,
      iconUrl: categoryDraft.iconUrl.trim() || null,
    };
    run(categoryDraft.id ? adminApi.updateCategory(categoryDraft.id, body) : adminApi.createCategory(body),
      categoryDraft.id ? 'Category updated.' : 'Category created.');
  };

  const saveSkill = () => {
    if (!skillDraft) return;
    const body = {
      categoryId: skillDraft.categoryId,
      name: skillDraft.name.trim(),
      description: skillDraft.description.trim() || null,
    };
    run(skillDraft.id ? adminApi.updateSkill(skillDraft.id, body) : adminApi.createSkill(body),
      skillDraft.id ? 'Service updated.' : 'Service added.');
  };

  if (error) return <ErrorNote message={error} />;
  if (!categories) return <Loading />;

  return (
    <>
      <PageHeader
        title="Services"
        subtitle="The categories and services people can offer and book. Retiring hides one from new work without touching history."
        action={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, color: t.text, cursor: 'pointer' }}>
              <input type="checkbox" checked={includeArchived} onChange={event => setIncludeArchived(event.target.checked)} />
              Show retired
            </label>
            <Button tone="primary" onClick={() => setCategoryDraft({ name: '', description: '', iconUrl: '' })}>
              ＋ New category
            </Button>
          </div>
        }
      />

      {categories.length === 0 ? (
        <Card><EmptyState icon="🧰" title="No categories yet" message="Create the first category, then add the services that sit under it." /></Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {categories.map(category => (
            <Card key={category.id} pad={0}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px',
                borderBottom: category.skills.length > 0 ? `1px solid ${t.border}` : 'none', flexWrap: 'wrap',
              }}>
                <div style={{ flex: 1, minWidth: 200 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                    <span style={{ fontSize: 15.5, fontWeight: 800, color: t.text }}>{category.name}</span>
                    {!category.active ? <Pill tone="warning">Retired</Pill> : null}
                    <Pill tone="neutral">{category.skillCount} service{category.skillCount === 1 ? '' : 's'}</Pill>
                  </div>
                  {category.description ? (
                    <div style={{ fontSize: 12.5, color: t.textMuted, marginTop: 3 }}>{category.description}</div>
                  ) : null}
                </div>
                <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
                  <Button size="sm" tone="subtle" onClick={() => setCategoryDraft({
                    id: category.id, name: category.name,
                    description: category.description ?? '', iconUrl: category.iconUrl ?? '',
                  })}>Edit</Button>
                  <Button size="sm" tone="subtle" onClick={() => setSkillDraft({
                    categoryId: category.id, name: '', description: '',
                  })}>＋ Service</Button>
                  <Button
                    size="sm"
                    tone={category.active ? 'danger' : 'primary'}
                    disabled={busy}
                    onClick={() => run(adminApi.setCategoryActive(category.id, !category.active),
                      category.active ? 'Category retired.' : 'Category restored.')}
                  >
                    {category.active ? 'Retire' : 'Restore'}
                  </Button>
                </div>
              </div>

              {category.skills.length > 0 ? (
                <div style={{ padding: '8px 18px 14px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {category.skills.map((skill: AdminSkill) => (
                    <div key={skill.id} style={{
                      display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 10,
                      background: t.surfaceMuted, flexWrap: 'wrap',
                    }}>
                      <div style={{ flex: 1, minWidth: 180 }}>
                        <span style={{ fontSize: 13.5, fontWeight: 700, color: skill.active ? t.text : t.textSubtle }}>{skill.name}</span>
                        {!skill.active ? <span style={{ marginLeft: 8 }}><Pill tone="warning">Retired</Pill></span> : null}
                        {skill.description ? (
                          <div style={{ fontSize: 12, color: t.textMuted, marginTop: 2 }}>{skill.description}</div>
                        ) : null}
                      </div>
                      <span style={{ fontSize: 12, color: t.textSubtle }}>
                        {skill.providerCount} provider{skill.providerCount === 1 ? '' : 's'}
                      </span>
                      <Button size="sm" tone="subtle" onClick={() => setSkillDraft({
                        id: skill.id, categoryId: skill.categoryId, name: skill.name, description: skill.description ?? '',
                      })}>Edit</Button>
                      <Button
                        size="sm"
                        tone={skill.active ? 'danger' : 'primary'}
                        disabled={busy}
                        onClick={() => run(adminApi.setSkillActive(skill.id, !skill.active),
                          skill.active ? 'Service retired.' : 'Service restored.')}
                      >
                        {skill.active ? 'Retire' : 'Restore'}
                      </Button>
                    </div>
                  ))}
                </div>
              ) : null}
            </Card>
          ))}
        </div>
      )}

      {categoryDraft ? (
        <Modal title={categoryDraft.id ? 'Edit category' : 'New category'} onClose={() => setCategoryDraft(null)}>
          <Field label="Name">
            <Input value={categoryDraft.name} onChange={value => setCategoryDraft({ ...categoryDraft, name: value })} autoFocus placeholder="e.g. Home repair" />
          </Field>
          <Field label="Description" hint="Shown to people browsing services.">
            <Textarea value={categoryDraft.description} onChange={value => setCategoryDraft({ ...categoryDraft, description: value })} rows={2} />
          </Field>
          <Field label="Icon URL (optional)">
            <Input value={categoryDraft.iconUrl} onChange={value => setCategoryDraft({ ...categoryDraft, iconUrl: value })} placeholder="https://…" />
          </Field>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button tone="subtle" onClick={() => setCategoryDraft(null)}>Cancel</Button>
            <Button tone="primary" disabled={busy || categoryDraft.name.trim().length < 2} onClick={saveCategory}>
              {busy ? 'Saving…' : 'Save'}
            </Button>
          </div>
        </Modal>
      ) : null}

      {skillDraft ? (
        <Modal title={skillDraft.id ? 'Edit service' : 'New service'} onClose={() => setSkillDraft(null)}>
          <Field label="Category">
            <select
              value={skillDraft.categoryId}
              onChange={event => setSkillDraft({ ...skillDraft, categoryId: event.target.value })}
              style={{
                width: '100%', padding: '10px 12px', borderRadius: 10, border: `1px solid ${t.borderStrong}`,
                background: t.surfaceMuted, color: t.text, fontSize: 13.5, fontFamily: 'inherit',
              }}
            >
              {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
            </select>
          </Field>
          <Field label="Name">
            <Input value={skillDraft.name} onChange={value => setSkillDraft({ ...skillDraft, name: value })} autoFocus placeholder="e.g. Plumbing" />
          </Field>
          <Field label="Description (optional)">
            <Textarea value={skillDraft.description} onChange={value => setSkillDraft({ ...skillDraft, description: value })} rows={2} />
          </Field>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button tone="subtle" onClick={() => setSkillDraft(null)}>Cancel</Button>
            <Button tone="primary" disabled={busy || skillDraft.name.trim().length < 2} onClick={saveSkill}>
              {busy ? 'Saving…' : 'Save'}
            </Button>
          </div>
        </Modal>
      ) : null}

      <Toasts toasts={toasts} />
    </>
  );
}
