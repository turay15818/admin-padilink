/**
 * The front page. Numbers first, then what has actually been happening — an admin console
 * whose home screen is only counters tells you the platform's size but never its state.
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '../theme/ThemeProvider';
import { Card, ErrorNote, Loading, PageHeader, Pill, timeAgo } from '../components/ui';
import { adminApi, type ConsoleSummary } from '../api/admin';
import { AuditRowLine } from './Audit';

function Stat({ label, value, tone, hint }: { label: string; value: number | string; tone?: string; hint?: string }) {
  const { t } = useTheme();
  return (
    <Card pad={16}>
      <div style={{ fontSize: 11.5, fontWeight: 800, letterSpacing: 0.7, color: t.textSubtle, textTransform: 'uppercase' }}>{label}</div>
      <div style={{ fontSize: 27, fontWeight: 800, color: tone ?? t.text, marginTop: 6, letterSpacing: -0.5 }}>{value}</div>
      {hint ? <div style={{ fontSize: 11.5, color: t.textSubtle, marginTop: 3 }}>{hint}</div> : null}
    </Card>
  );
}

/** Signups over 30 days. Bars, because the shape is the point, not the individual values. */
function Trend({ points }: { points: { day: string; count: number }[] }) {
  const { t } = useTheme();
  if (points.length === 0) {
    return <div style={{ color: t.textSubtle, fontSize: 13, padding: '20px 0' }}>No signups in the last 30 days.</div>;
  }
  const max = Math.max(...points.map(point => point.count), 1);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 110, marginTop: 12 }}>
      {points.map(point => (
        <div
          key={point.day}
          title={`${new Date(point.day).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}: ${point.count}`}
          style={{
            flex: 1, minWidth: 4, height: `${Math.max(4, (point.count / max) * 100)}%`,
            background: t.brand, borderRadius: '4px 4px 2px 2px', opacity: 0.55 + 0.45 * (point.count / max),
          }}
        />
      ))}
    </div>
  );
}

export function Overview() {
  const { t } = useTheme();
  const [summary, setSummary] = useState<ConsoleSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    adminApi.summary()
      .then(setSummary)
      .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : 'Could not load the overview.'));
  }, []);

  if (error) return <ErrorNote message={error} />;
  if (!summary) return <Loading />;

  return (
    <>
      <PageHeader
        title="Overview"
        subtitle="The platform at a glance, and every administrator action behind it."
      />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(178px, 1fr))', gap: 12 }}>
        <Stat label="People" value={summary.totalUsers} hint={`${summary.newUsers7d} joined this week`} />
        <Stat label="Active" value={summary.activeUsers} tone={t.success} />
        <Stat label="Suspended" value={summary.suspendedUsers} tone={summary.suspendedUsers > 0 ? t.warning : undefined} />
        <Stat label="Blocked" value={summary.blockedUsers} tone={summary.blockedUsers > 0 ? t.danger : undefined} />
        <Stat label="Providers" value={summary.providers} />
        <Stat label="Companies" value={summary.companies} />
        <Stat label="Services" value={summary.skills} hint={`in ${summary.categories} categories`} />
        <Stat label="Admin actions" value={summary.adminActions24h} hint="last 24 hours" />
      </div>

      {(summary.sensitiveActions7d > 0 || summary.failedAdminAttempts7d > 0) ? (
        <Card style={{ marginTop: 14, display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: 13.5, fontWeight: 700, color: t.text }}>Worth a look this week</span>
          {summary.sensitiveActions7d > 0 ? (
            <Pill tone="warning">{summary.sensitiveActions7d} sensitive action{summary.sensitiveActions7d === 1 ? '' : 's'}</Pill>
          ) : null}
          {summary.failedAdminAttempts7d > 0 ? (
            <Pill tone="danger">{summary.failedAdminAttempts7d} refused attempt{summary.failedAdminAttempts7d === 1 ? '' : 's'}</Pill>
          ) : null}
          <Link to="/audit" style={{ marginLeft: 'auto', color: t.brand, fontSize: 13, fontWeight: 700, textDecoration: 'none' }}>
            Open the audit trail →
          </Link>
        </Card>
      ) : null}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(330px, 1fr))', gap: 14, marginTop: 14 }}>
        <Card>
          <div style={{ fontSize: 14.5, fontWeight: 800, color: t.text }}>New people, 30 days</div>
          <div style={{ fontSize: 12.5, color: t.textMuted }}>{summary.newUsers30d} in total</div>
          <Trend points={summary.signupTrend} />
        </Card>

        <Card>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <div style={{ flex: 1, fontSize: 14.5, fontWeight: 800, color: t.text }}>Latest activity</div>
            <Link to="/audit" style={{ color: t.brand, fontSize: 12.5, fontWeight: 700, textDecoration: 'none' }}>All →</Link>
          </div>
          {summary.recentActivity.length === 0 ? (
            <div style={{ color: t.textSubtle, fontSize: 13, padding: '14px 0' }}>Nothing yet.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {summary.recentActivity.slice(0, 8).map(entry => (
                <AuditRowLine key={entry.id} entry={entry} when={timeAgo(entry.at)} />
              ))}
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
