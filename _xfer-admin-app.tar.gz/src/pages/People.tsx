/**
 * People: find an account, open it, and act on it.
 *
 * Every destructive move goes through a dialog that asks for a reason, because the reason
 * is what the audit trail will be read for later. The dialog states plainly what the
 * person will experience — "cannot sign in" is more useful than the word "blocked".
 */
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useTheme } from '../theme/ThemeProvider';
import {
  Button, Card, Cell, EmptyState, ErrorNote, Field, Input, Loading, Modal, PageHeader,
  Pill, Row, Table, Textarea, Toasts, fmtDate, fmtDateTime, statusTone, timeAgo, useToasts,
} from '../components/ui';
import { adminApi, AccountStatus, type AdminIdentity, type AdminUserDetail, type AdminUserSearch } from '../api/admin';
import { AuditRowLine } from './Audit';

/* ---------------- list ---------------- */

export function People() {
  const { t } = useTheme();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState<AdminUserSearch | null>(null);
  const [pageIndex, setPageIndex] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setBusy(true);
    const timer = window.setTimeout(() => {
      adminApi.users(search, pageIndex)
        .then(result => { setPage(result); setError(null); })
        .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : 'Could not load people.'))
        .finally(() => setBusy(false));
    }, 240);
    return () => window.clearTimeout(timer);
  }, [search, pageIndex]);

  const totalPages = page ? Math.max(1, Math.ceil(page.totalCount / page.pageSize)) : 1;

  return (
    <>
      <PageHeader title="People" subtitle="Every account on the platform. Open one to see what they have done and act on it." />

      <Card pad={14} style={{ marginBottom: 14 }}>
        <Input
          value={search}
          onChange={value => { setSearch(value); setPageIndex(1); }}
          placeholder="Search by name or email…"
        />
      </Card>

      {error ? <ErrorNote message={error} /> : null}

      <Card pad={0}>
        {!page && busy ? <Loading /> : (page?.items.length ?? 0) === 0 ? (
          <EmptyState icon="👥" title="Nobody matches" message="Try a different name or email." />
        ) : (
          <Table head={['Name', 'Email', 'Type', 'Status', 'Joined', '']}>
            {page!.items.map(user => (
              <Row key={user.id} onClick={() => navigate(`/users/${user.id}`)}>
                <Cell><span style={{ fontWeight: 700 }}>{user.name}</span></Cell>
                <Cell style={{ color: t.textMuted }}>{user.email ?? '—'}</Cell>
                <Cell><Pill tone={user.userType >= 3 ? 'accent' : 'neutral'}>{user.userTypeName}</Pill></Cell>
                <Cell><Pill tone={statusTone(user.status)}>{user.statusName}</Pill></Cell>
                <Cell style={{ color: t.textMuted }}>{fmtDate(user.dateCreated)}</Cell>
                <Cell style={{ textAlign: 'right', color: t.textSubtle }}>→</Cell>
              </Row>
            ))}
          </Table>
        )}
      </Card>

      {page && page.totalCount > page.pageSize ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 14, justifyContent: 'center' }}>
          <Button size="sm" tone="subtle" disabled={pageIndex <= 1} onClick={() => setPageIndex(index => index - 1)}>← Previous</Button>
          <span style={{ fontSize: 12.5, color: t.textMuted }}>Page {page.pageIndex} of {totalPages} · {page.totalCount} people</span>
          <Button size="sm" tone="subtle" disabled={pageIndex >= totalPages} onClick={() => setPageIndex(index => index + 1)}>Next →</Button>
        </div>
      ) : null}
    </>
  );
}

/* ---------------- detail ---------------- */

const ROLES = ['INDIVIDUAL', 'PROVIDER', 'COMPANY', 'ADMIN', 'SUPER_ADMIN'];

export function Person({ identity }: { identity: AdminIdentity }) {
  const { userId } = useParams();
  const { t } = useTheme();
  const { toasts, push } = useToasts();
  const [user, setUser] = useState<AdminUserDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [statusTarget, setStatusTarget] = useState<number | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [rolesOpen, setRolesOpen] = useState(false);
  const [draftRoles, setDraftRoles] = useState<string[]>([]);

  const load = useCallback(() => {
    if (!userId) return;
    adminApi.user(userId)
      .then(result => { setUser(result); setDraftRoles(result.roles); setError(null); })
      .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : 'Could not load this account.'));
  }, [userId]);
  useEffect(load, [load]);

  if (error) return <ErrorNote message={error} />;
  if (!user) return <Loading />;

  const applyStatus = () => {
    if (statusTarget === null || !userId) return;
    setBusy(true);
    adminApi.setUserStatus(userId, statusTarget, reason.trim() || null)
      .then(result => {
        setUser(result);
        setStatusTarget(null);
        setReason('');
        push(`${result.name} is now ${result.statusName.toLowerCase()}.`);
      })
      .catch((caught: unknown) => push(caught instanceof Error ? caught.message : 'That did not work.', 'error'))
      .finally(() => setBusy(false));
  };

  const applyRoles = () => {
    if (!userId) return;
    setBusy(true);
    adminApi.setUserRoles(userId, draftRoles, reason.trim() || null)
      .then(result => {
        setUser(result);
        setRolesOpen(false);
        setReason('');
        push(`Roles updated for ${result.name}.`);
      })
      .catch((caught: unknown) => push(caught instanceof Error ? caught.message : 'That did not work.', 'error'))
      .finally(() => setBusy(false));
  };

  const facts: [string, string][] = [
    ['Email', user.email ?? '—'],
    ['Phone', user.phoneNumber ?? '—'],
    ['Joined', fmtDate(user.dateCreated)],
    ['Last change', user.lastUpdated ? fmtDateTime(user.lastUpdated) : '—'],
    ['Email verified', user.emailVerified ? 'Yes' : 'No'],
    ['Phone verified', user.phoneVerified ? 'Yes' : 'No'],
  ];

  const activity: [string, number][] = [
    ['Bookings made', user.bookingsAsCustomer],
    ['Jobs completed', user.bookingsAsProvider],
    ['Jobs posted', user.jobsPosted],
    ['Classes taught', user.classesTaught],
    ['Certificates', user.certificatesEarned],
  ];

  const statusAction = (target: number, label: string, tone: 'primary' | 'danger' | 'ghost') => (
    <Button tone={tone} disabled={user.status === target} onClick={() => { setStatusTarget(target); setReason(''); }}>
      {label}
    </Button>
  );

  return (
    <>
      <Link to="/users" style={{ fontSize: 13, color: t.textMuted, textDecoration: 'none' }}>← All people</Link>

      <PageHeader
        title={user.name}
        subtitle={user.email ?? undefined}
        action={
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {statusAction(AccountStatus.Active, 'Activate', 'primary')}
            {statusAction(AccountStatus.Suspended, 'Suspend', 'ghost')}
            {statusAction(AccountStatus.Blocked, 'Block', 'danger')}
          </div>
        }
      />

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
        <Pill tone={statusTone(user.status)}>{user.statusName}</Pill>
        <Pill tone={user.userType >= 3 ? 'accent' : 'neutral'}>{user.userTypeName}</Pill>
        {user.hasProviderProfile ? (
          <Pill tone={user.providerVerified ? 'success' : 'info'}>
            {user.providerVerified ? '✓ Verified provider' : 'Provider'}{user.providerBusinessName ? ` · ${user.providerBusinessName}` : ''}
          </Pill>
        ) : null}
        {user.roles.map(role => <Pill key={role} tone="info">{role}</Pill>)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 14 }}>
        <Card>
          <div style={{ fontSize: 14.5, fontWeight: 800, color: t.text, marginBottom: 10 }}>Account</div>
          {facts.map(([label, value]) => (
            <div key={label} style={{ display: 'flex', gap: 12, padding: '7px 0', borderBottom: `1px solid ${t.border}` }}>
              <div style={{ width: 120, flexShrink: 0, fontSize: 12.5, color: t.textSubtle, fontWeight: 700 }}>{label}</div>
              <div style={{ fontSize: 13, color: t.text }}>{value}</div>
            </div>
          ))}

          <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <Button
              size="sm"
              tone="subtle"
              disabled={!identity.isSuperAdmin}
              title={identity.isSuperAdmin ? undefined : 'Only a super administrator can change roles'}
              onClick={() => { setDraftRoles(user.roles); setReason(''); setRolesOpen(true); }}
            >
              Manage roles
            </Button>
            <Link to={`/audit?entityId=${user.id}`} style={{ fontSize: 12.5, color: t.brand, fontWeight: 700, textDecoration: 'none' }}>
              Full history →
            </Link>
          </div>
        </Card>

        <Card>
          <div style={{ fontSize: 14.5, fontWeight: 800, color: t.text, marginBottom: 10 }}>On the platform</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 10 }}>
            {activity.map(([label, value]) => (
              <div key={label} style={{ background: t.surfaceMuted, borderRadius: 10, padding: '11px 13px' }}>
                <div style={{ fontSize: 20, fontWeight: 800, color: t.text }}>{value}</div>
                <div style={{ fontSize: 11.5, color: t.textSubtle, fontWeight: 600 }}>{label}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card style={{ marginTop: 14 }}>
        <div style={{ fontSize: 14.5, fontWeight: 800, color: t.text, marginBottom: 4 }}>What administrators did to this account</div>
        {user.recentActivity.length === 0 ? (
          <div style={{ color: t.textSubtle, fontSize: 13, padding: '12px 0' }}>Nothing yet — this account has never been touched from the console.</div>
        ) : (
          user.recentActivity.map(entry => <AuditRowLine key={entry.id} entry={entry} when={timeAgo(entry.at)} />)
        )}
      </Card>

      {statusTarget !== null ? (
        <Modal
          title={statusTarget === AccountStatus.Active ? 'Reactivate this account'
            : statusTarget === AccountStatus.Suspended ? 'Suspend this account' : 'Block this account'}
          onClose={() => setStatusTarget(null)}
        >
          <p style={{ color: t.textMuted, fontSize: 13.5, lineHeight: 1.65, marginTop: 0 }}>
            {statusTarget === AccountStatus.Active
              ? `${user.name} will be able to sign in and use Vacancy normally again.`
              : statusTarget === AccountStatus.Suspended
                ? `${user.name} will not be able to sign in. Their bookings, classes and history stay exactly as they are, and you can lift this at any time.`
                : `${user.name} will be blocked from signing in. Use this for abuse and fraud — suspension is the reversible, softer option.`}
          </p>

          {statusTarget !== AccountStatus.Active ? (
            <Field label="Reason" hint="Required. This is recorded against your name on the audit trail.">
              <Textarea value={reason} onChange={setReason} rows={3} placeholder="e.g. Repeated no-shows reported by three customers" />
            </Field>
          ) : (
            <Field label="Note (optional)">
              <Textarea value={reason} onChange={setReason} rows={2} placeholder="e.g. Appeal upheld — evidence provided" />
            </Field>
          )}

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 6 }}>
            <Button tone="subtle" onClick={() => setStatusTarget(null)}>Cancel</Button>
            <Button
              tone={statusTarget === AccountStatus.Blocked ? 'danger' : 'primary'}
              disabled={busy || (statusTarget !== AccountStatus.Active && reason.trim().length === 0)}
              onClick={applyStatus}
            >
              {busy ? 'Working…' : statusTarget === AccountStatus.Active ? 'Reactivate' : statusTarget === AccountStatus.Suspended ? 'Suspend' : 'Block'}
            </Button>
          </div>
        </Modal>
      ) : null}

      {rolesOpen ? (
        <Modal title={`Roles for ${user.name}`} onClose={() => setRolesOpen(false)}>
          <p style={{ color: t.textMuted, fontSize: 13, lineHeight: 1.6, marginTop: 0 }}>
            Roles decide what this account can do. Granting ADMIN gives access to this console;
            SUPER_ADMIN additionally allows acting on other administrators.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 14 }}>
            {ROLES.map(role => {
              const on = draftRoles.includes(role);
              return (
                <label
                  key={role}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 10,
                    border: `1px solid ${on ? t.brand : t.border}`, background: on ? t.brandSoft : t.surfaceMuted,
                    cursor: 'pointer', fontSize: 13.5, fontWeight: 600, color: t.text,
                  }}
                >
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={event => setDraftRoles(list => event.target.checked ? [...list, role] : list.filter(item => item !== role))}
                  />
                  {role}
                  {role === 'SUPER_ADMIN' ? <span style={{ marginLeft: 'auto' }}><Pill tone="danger">full power</Pill></span> : null}
                </label>
              );
            })}
          </div>
          <Field label="Reason (optional)">
            <Input value={reason} onChange={setReason} placeholder="e.g. Promoted to operations lead" />
          </Field>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button tone="subtle" onClick={() => setRolesOpen(false)}>Cancel</Button>
            <Button tone="primary" disabled={busy} onClick={applyRoles}>{busy ? 'Saving…' : 'Save roles'}</Button>
          </div>
        </Modal>
      ) : null}

      <Toasts toasts={toasts} />
    </>
  );
}
