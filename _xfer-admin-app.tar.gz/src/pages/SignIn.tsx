/**
 * The console's front door. A non-administrator who signs in successfully is still turned
 * away here — and that attempt is already on the audit trail by the time this screen says so.
 */
import { useState } from 'react';
import { useTheme } from '../theme/ThemeProvider';
import { Button, ErrorNote, Field, Input, Spinner } from '../components/ui';
import { VacancyMark } from '../app/Shell';
import { adminApi, type AdminIdentity } from '../api/admin';
import { config } from '../api/client';

export function SignIn({ onSignedIn }: { onSignedIn: (identity: AdminIdentity) => void }) {
  const { t, name, toggle } = useTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = () => {
    if (busy) return;
    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }
    setBusy(true);
    setError(null);
    adminApi.signIn(email.trim(), password)
      .then(result => onSignedIn(result.identity))
      .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : 'Sign-in failed.'))
      .finally(() => setBusy(false));
  };

  return (
    <div style={{ minHeight: '100vh', background: t.bg, display: 'grid', placeItems: 'center', padding: 20 }}>
      <div style={{ position: 'fixed', top: 16, right: 18 }}>
        <Button size="sm" tone="subtle" onClick={toggle}>{name === 'dark' ? '☀ Light' : '☾ Dark'}</Button>
      </div>

      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'center', marginBottom: 8 }}>
          <VacancyMark size={38} onNavy={false} />
          <div>
            <div style={{ fontSize: 24, fontWeight: 900, color: t.text, letterSpacing: -0.4 }}>Vacancy</div>
            <div style={{ fontSize: 10.5, letterSpacing: 2, color: t.accent, fontWeight: 800 }}>ADMIN CONSOLE</div>
          </div>
        </div>

        <p style={{ textAlign: 'center', color: t.textMuted, fontSize: 13, margin: '0 0 22px', lineHeight: 1.6 }}>
          Everything you do here is recorded against your name.
        </p>

        <div style={{
          background: t.surface, border: `1px solid ${t.border}`, borderRadius: 16,
          padding: 22, boxShadow: t.shadow,
        }}>
          <Field label="Work email">
            <Input value={email} onChange={setEmail} type="email" placeholder="you@vacancy.app" autoFocus onEnter={submit} disabled={busy} />
          </Field>
          <Field label="Password">
            <Input value={password} onChange={setPassword} type="password" placeholder="••••••••" onEnter={submit} disabled={busy} />
          </Field>

          {error ? <div style={{ margin: '4px 0 12px' }}><ErrorNote message={error} /></div> : null}

          <Button tone="primary" onClick={submit} disabled={busy} style={{ width: '100%', justifyContent: 'center' }}>
            {busy ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}><Spinner size={14} /> Checking…</span> : 'Sign in'}
          </Button>

          <p style={{ color: t.textSubtle, fontSize: 11.5, textAlign: 'center', margin: '14px 0 0', lineHeight: 1.6 }}>
            Credentials are sealed in the browser before they travel.<br />
            API: {config.apiBaseUrl}
          </p>
        </div>
      </div>
    </div>
  );
}
