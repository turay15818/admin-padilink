import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The console runs on its own port so it never shares a cookie jar or a service worker
// with the public site.
export default defineConfig({
  plugins: [react()],
  server: { port: 5273, strictPort: false },
  build: { outDir: 'dist', sourcemap: false },
});
