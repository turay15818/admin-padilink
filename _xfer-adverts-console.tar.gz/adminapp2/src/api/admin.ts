/** The admin console's wire contract — mirrors ApiVacancy.Application/Admin/DTOs. */
import { apiRequest, setSession, type Session } from './client';
import { securePost, type AdminDevice } from './secure';

const BASE = '/api/v1/secure/admin/console';
const DASHBOARD = '/api/v1/secure/admin/dashboard';
const ADVERTS = '/api/v1/secure/admin/adverts';
const AUTH = '/api/v1/admin/session';
const id = encodeURIComponent;

export type AdminIdentity = {
  userId: string;
  name: string;
  email: string | null;
  roles: string[];
  permissions: string[];
  canManageUsers: boolean;
  canManageCatalog: boolean;
  isSuperAdmin: boolean;
};

export type AuditEntry = {
  id: string;
  actorUserId: string;
  actorName: string;
  actorEmail: string | null;
  action: string;
  actionLabel: string;
  entityType: string;
  entityId: string | null;
  entityLabel: string | null;
  summary: string;
  reason: string | null;
  changesJson: string | null;
  ipAddress: string | null;
  userAgent: string | null;
  severity: number;
  severityLabel: string;
  succeeded: boolean;
  failureReason: string | null;
  at: string;
};

export type AuditPage = {
  items: AuditEntry[];
  totalCount: number;
  pageIndex: number;
  pageSize: number;
  knownActions: string[];
};

export type ConsoleSummary = {
  totalUsers: number; activeUsers: number; suspendedUsers: number; blockedUsers: number;
  newUsers7d: number; newUsers30d: number; providers: number; companies: number;
  categories: number; skills: number;
  adminActions24h: number; sensitiveActions7d: number; failedAdminAttempts7d: number;
  recentActivity: AuditEntry[];
  signupTrend: { day: string; count: number }[];
};

export type AdminUserRow = {
  id: string; name: string; email?: string | null;
  userType: number; userTypeName: string;
  status: number; statusName: string;
  emailVerified: boolean; dateCreated: string;
};

export type AdminUserSearch = { items: AdminUserRow[]; totalCount: number; pageIndex: number; pageSize: number };

export type AdminUserDetail = {
  id: string; name: string; email: string | null; phoneNumber: string | null;
  userType: number; userTypeName: string;
  status: number; statusName: string;
  emailVerified: boolean; phoneVerified: boolean; active: boolean;
  dateCreated: string; lastUpdated: string | null;
  roles: string[];
  bookingsAsCustomer: number; bookingsAsProvider: number; jobsPosted: number;
  classesTaught: number; certificatesEarned: number;
  hasProviderProfile: boolean; providerBusinessName: string | null; providerVerified: boolean;
  recentActivity: AuditEntry[];
};

export type AdminSkill = {
  id: string; categoryId: string; categoryName: string; name: string;
  description: string | null; active: boolean; providerCount: number; dateCreated: string;
};

export type AdminCategory = {
  id: string; name: string; description: string | null; iconUrl: string | null;
  active: boolean; skillCount: number; dateCreated: string; skills: AdminSkill[];
};

/** 2 active · 3 suspended · 4 blocked — matches AccountStatus on the server. */
export const AccountStatus = { Active: 2, Suspended: 3, Blocked: 4 } as const;

/* ---------- paged catalogue ---------- */

export type CatalogQuery = {
  search?: string;
  categoryId?: string;
  status?: string;
  sort?: string;
  pageIndex?: number;
  pageSize?: number;
};

export type CategoryPage = {
  items: AdminCategory[];
  totalCount: number; pageIndex: number; pageSize: number;
  activeCount: number; retiredCount: number; totalSkills: number;
};

export type SkillPage = {
  items: AdminSkill[];
  totalCount: number; pageIndex: number; pageSize: number;
  activeCount: number; retiredCount: number;
};

/* ---------- uploaded documents ---------- */

export type AdminDocument = {
  id: string;
  ownerUserId: string; ownerName: string; ownerEmail: string | null;
  ownerType: number; ownerTypeName: string;
  documentTypeId: string; documentTypeName: string;
  fileName: string; fileUrl: string; contentType: string; fileSize: number;
  status: number; statusName: string;
  rejectionReason: string | null;
  dateCreated: string; dateUpdated: string | null; decidedBy: string | null;
  extractedFullName: string | null;
  extractedDocumentNumber: string | null;
  extractedDateOfBirth: string | null;
  extractedExpiryDate: string | null;
  confidenceScore: number | null;
  scanIsExpired: boolean | null;
  scanIsReadable: boolean | null;
  ownerIsProvider: boolean;
  providerVerificationStatus: string | null;
  ownerDocumentCount: number;
  ownerApprovedCount: number;
};

export type DocumentPage = {
  items: AdminDocument[];
  totalCount: number; pageIndex: number; pageSize: number;
  awaitingCount: number; approvedCount: number; rejectedCount: number;
};

/** 1 pending · 2 scanning · 3 scanned · 4 approved · 5 rejected · 6 expired. */
export const DocumentStatus = {
  Pending: 1, Scanning: 2, Scanned: 3, Approved: 4, Rejected: 5, Expired: 6,
} as const;

/* ---------- adverts ---------- */

export type Advert = {
  id: string;
  kicker: string | null; title: string; body: string | null; meta: string | null;
  imageUrl: string | null; ctaLabel: string | null;
  tone: number; toneName: string;
  targetType: number; targetTypeName: string;
  targetEntityId: string | null; targetRoute: string | null; targetUrl: string | null; targetLabel: string | null;
  placements: number; placementNames: string[];
  audience: number; audienceNames: string[];
  startsAt: string | null; endsAt: string | null;
  priority: number; active: boolean; live: boolean; statusLabel: string;
  impressionCount: number; clickCount: number; clickRate: number;
  lastShownAt: string | null; dateCreated: string;
};

export type AdvertPage = {
  items: Advert[];
  totalCount: number; pageIndex: number; pageSize: number;
  liveCount: number; scheduledCount: number; endedCount: number;
};

export type AdvertWrite = {
  kicker?: string | null;
  title: string;
  body?: string | null;
  meta?: string | null;
  imageUrl?: string | null;
  ctaLabel?: string | null;
  tone: number;
  targetType: number;
  targetEntityId?: string | null;
  targetRoute?: string | null;
  targetUrl?: string | null;
  placements: string[];
  audience: string[];
  startsAt?: string | null;
  endsAt?: string | null;
  priority: number;
  active: boolean;
};

export type AdvertTargetOption = { id: string; label: string; detail: string | null };
export type AdvertScreenOption = { key: string; label: string };

/** Mirrors AdvertTone / AdvertTargetType on the server. */
export const AdvertTone = { Primary: 1, Secondary: 2, Verified: 3, Dark: 4 } as const;
export const AdvertTargetType = {
  None: 1, Provider: 2, Skill: 3, Category: 4, TrainingClass: 5, JobPost: 6, Screen: 7, ExternalUrl: 8,
} as const;

export const PLACEMENTS = [
  { value: 'MobilePromoRail', label: 'Mobile — promo rail', detail: 'The snap-scrolling rail on Discover' },
  { value: 'MobileHero', label: 'Mobile — hero carousel', detail: 'Full width, top of Discover' },
  { value: 'WebDiscover', label: 'Web — Discover', detail: 'The in-app home page' },
  { value: 'WebLanding', label: 'Web — landing page', detail: 'Seen before anyone signs in' },
];

export const AUDIENCES = [
  { value: 'SignedOut', label: 'Signed out', detail: 'Visitors who have not joined' },
  { value: 'Customers', label: 'Customers', detail: 'Signed-in people who book work' },
  { value: 'Providers', label: 'Providers', detail: 'People who offer work' },
  { value: 'Companies', label: 'Companies', detail: 'Company accounts' },
];

function queryString(filters: Record<string, unknown>) {
  const query = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && `${value}`.trim() !== '') query.set(key, String(value));
  });
  return query.toString();
}

/* ---------- two-step sign-in ---------- */

/**
 * Step one's answer. Note what is NOT here: no token, no user id, no roles. Knowing the
 * password gets you a countdown and a code in an inbox you must already control.
 */
export type AdminChallenge = {
  challengeId: string;
  maskedEmail: string;
  expiresAt: string;
  resendAvailableAt: string;
  codeLength: number;
  deviceLabel: string;
  /** False the first time this browser is seen. The screen says so, loudly. */
  recognisedDevice: boolean;
};

/** Step two's answer — the only response in the whole flow that can reach the API. */
type AdminSessionResponse = {
  accessToken: string;
  expiresAt: string;
  userId: string;
  name: string;
  email: string | null;
  roles: string[];
  isSuperAdmin: boolean;
};

export const adminApi = {
  /**
   * Password + console entitlement. Both are checked before a code is sent, and an
   * unknown address fails exactly like a wrong password so the screen cannot be used
   * to find out who has an account here.
   */
  start(email: string, password: string, device: AdminDevice) {
    return securePost<AdminChallenge>(`${AUTH}/start`, { email, password, device });
  },

  /**
   * The second factor. On success the session is stored and the identity re-fetched from
   * the API — the console never decides for itself that a token belongs to an administrator.
   */
  async verify(challengeId: string, code: string, device: AdminDevice): Promise<AdminIdentity> {
    const auth = await securePost<AdminSessionResponse>(`${AUTH}/verify`, { challengeId, code, device });

    const session: Session = {
      accessToken: auth.accessToken,
      refreshToken: null,   // the console is short-lived by design: no silent renewal
      expiresAt: auth.expiresAt,
      name: auth.name,
      email: auth.email,
    };
    setSession(session);

    try {
      return await adminApi.me();
    } catch (error) {
      setSession(null);   // entitlement vanished between the two steps — leave no token behind
      throw error;
    }
  },

  /** A fresh code on the same challenge. The cool-down is enforced server-side too. */
  resend(challengeId: string) {
    return securePost<AdminChallenge>(`${AUTH}/resend`, { challengeId });
  },

  me() {
    return apiRequest<AdminIdentity>(`${BASE}/me`);
  },

  summary() {
    return apiRequest<ConsoleSummary>(`${BASE}/summary`);
  },

  // ---- accounts ----
  users(search: string, pageIndex = 1, pageSize = 25) {
    const query = new URLSearchParams({ pageIndex: String(pageIndex), pageSize: String(pageSize) });
    if (search.trim()) query.set('search', search.trim());
    return apiRequest<AdminUserSearch>(`${DASHBOARD}/users?${query}`);
  },

  user(userId: string) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}`);
  },

  setUserStatus(userId: string, status: number, reason: string | null) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}/status`,
      { method: 'POST', body: { status, reason } });
  },

  setUserRoles(userId: string, roles: string[], reason: string | null) {
    return apiRequest<AdminUserDetail>(`${BASE}/users/${id(userId)}/roles`,
      { method: 'POST', body: { roles, reason } });
  },

  // ---- service catalogue ----
  catalog(includeArchived: boolean) {
    return apiRequest<AdminCategory[]>(`${BASE}/catalog?includeArchived=${includeArchived}`);
  },

  createCategory(body: { name: string; description?: string | null; iconUrl?: string | null }) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories`, { method: 'POST', body });
  },

  updateCategory(categoryId: string, body: { name: string; description?: string | null; iconUrl?: string | null }) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories/${id(categoryId)}`, { method: 'PUT', body });
  },

  setCategoryActive(categoryId: string, active: boolean, reason?: string | null) {
    return apiRequest<AdminCategory>(`${BASE}/catalog/categories/${id(categoryId)}/active`,
      { method: 'POST', body: { active, reason } });
  },

  createSkill(body: { categoryId: string; name: string; description?: string | null }) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills`, { method: 'POST', body });
  },

  updateSkill(skillId: string, body: { categoryId: string; name: string; description?: string | null }) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills/${id(skillId)}`, { method: 'PUT', body });
  },

  setSkillActive(skillId: string, active: boolean, reason?: string | null) {
    return apiRequest<AdminSkill>(`${BASE}/catalog/skills/${id(skillId)}/active`,
      { method: 'POST', body: { active, reason } });
  },

  /** Categories, searched and paged by the API — not by this browser. */
  categoryPage(query: CatalogQuery) {
    return apiRequest<CategoryPage>(`${BASE}/catalog/category-search?${queryString(query)}`);
  },

  skillPage(query: CatalogQuery) {
    return apiRequest<SkillPage>(`${BASE}/catalog/skill-search?${queryString(query)}`);
  },

  // ---- uploaded documents ----
  documents(query: {
    search?: string; status?: string; documentTypeId?: string; ownerType?: string;
    sort?: string; pageIndex?: number; pageSize?: number;
  }) {
    return apiRequest<DocumentPage>(`${BASE}/documents?${queryString(query)}`);
  },

  document(documentId: string) {
    return apiRequest<AdminDocument>(`${BASE}/documents/${id(documentId)}`);
  },

  decideDocument(documentId: string, body: {
    approved: boolean; reason?: string | null; alsoVerifyProvider?: boolean; silent?: boolean;
  }) {
    return apiRequest<AdminDocument>(`${BASE}/documents/${id(documentId)}/decision`, { method: 'POST', body });
  },

  // ---- passwords (encrypted in transit, administrators only) ----
  changeMyPassword(currentPassword: string, newPassword: string) {
    return securePost<{ message: string }>(`${BASE}/me/password`, { currentPassword, newPassword });
  },

  resetPassword(userId: string, body: { newPassword: string; reason: string; notifyByEmail: boolean }) {
    return securePost<{ message: string }>(`${BASE}/users/${id(userId)}/password`, body);
  },

  // ---- adverts ----
  adverts(query: {
    search?: string; placement?: string; status?: string; sort?: string;
    pageIndex?: number; pageSize?: number;
  }) {
    return apiRequest<AdvertPage>(`${ADVERTS}?${queryString(query)}`);
  },

  advert(advertId: string) {
    return apiRequest<Advert>(`${ADVERTS}/${id(advertId)}`);
  },

  createAdvert(body: AdvertWrite) {
    return apiRequest<Advert>(ADVERTS, { method: 'POST', body });
  },

  updateAdvert(advertId: string, body: AdvertWrite) {
    return apiRequest<Advert>(`${ADVERTS}/${id(advertId)}`, { method: 'PUT', body });
  },

  setAdvertActive(advertId: string, active: boolean, reason?: string | null) {
    return apiRequest<Advert>(`${ADVERTS}/${id(advertId)}/active`, { method: 'POST', body: { active, reason } });
  },

  removeAdvert(advertId: string, reason: string) {
    return apiRequest<boolean>(`${ADVERTS}/${id(advertId)}?reason=${encodeURIComponent(reason)}`, { method: 'DELETE' });
  },

  advertTargets(targetType: string, search: string) {
    return apiRequest<AdvertTargetOption[]>(`${ADVERTS}/targets?${queryString({ targetType, search, take: 25 })}`);
  },

  advertScreens() {
    return apiRequest<AdvertScreenOption[]>(`${ADVERTS}/screens`);
  },

  // ---- audit ----
  audit(filters: {
    search?: string; action?: string; actorUserId?: string; entityId?: string;
    severity?: number; from?: string; to?: string; pageIndex?: number; pageSize?: number;
  }) {
    return apiRequest<AuditPage>(`${BASE}/audit?${queryString(filters)}`);
  },
};
