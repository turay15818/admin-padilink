/**
 * Session gate. Nothing renders until the API confirms this token belongs to an
 * administrator — the console never decides that for itself from a stored flag.
 */
import { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Shell } from './Shell';
import { SignIn } from '../pages/SignIn';
import { Overview } from '../pages/Overview';
import { People, Person } from '../pages/People';
import { Catalog } from '../pages/Catalog';
import { Audit } from '../pages/Audit';
import { Documents } from '../pages/Documents';
import { Adverts } from '../pages/Adverts';
import { Account } from '../pages/Account';
import { Loading } from '../components/ui';
import { adminApi, type AdminIdentity } from '../api/admin';
import { loadSession, onSessionChange } from '../api/client';

export function App() {
  const [identity, setIdentity] = useState<AdminIdentity | null>(null);
  const [checking, setChecking] = useState(true);

  // Re-check on boot, and whenever a 401 clears the session from under us.
  useEffect(() => {
    const verify = () => {
      if (!loadSession()) {
        setIdentity(null);
        setChecking(false);
        return;
      }
      adminApi.me()
        .then(setIdentity)
        .catch(() => setIdentity(null))
        .finally(() => setChecking(false));
    };
    verify();
    return onSessionChange(session => { if (!session) setIdentity(null); });
  }, []);

  if (checking) return <Loading label="Checking your access…" />;
  if (!identity) return <SignIn onSignedIn={setIdentity} />;

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Shell identity={identity} />}>
          <Route path="/" element={<Overview />} />
          <Route path="/users" element={<People />} />
          <Route path="/users/:userId" element={<Person identity={identity} />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/documents" element={<Documents />} />
          <Route path="/adverts" element={<Adverts />} />
          <Route path="/audit" element={<Audit />} />
          <Route path="/account" element={<Account identity={identity} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
